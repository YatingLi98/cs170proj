# CS170 Project Skeleton

See [the Guavabot website](http://guavabot.cs170.org/) to get started!
