# Put your solution here.

def solve(client):
    pass
